import socket

# Récupération des informations de l'utilisateur
server_ip = input("Entrez l'IP du serveur : ")
keywords = input("Entrez les 4 mots-clés (en 1 mot, Keyword1Keyword2...) : ")

# Création d'un socket et connexion au serveur
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.connect((server_ip, 12345))
    s.sendall(keywords.encode())
    
    # Réception de la réponse du serveur
    response = s.recv(1024).decode()
    print(response)
